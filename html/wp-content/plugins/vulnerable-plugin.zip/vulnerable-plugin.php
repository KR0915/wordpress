<?php
/*
Plugin Name: Vulnerable Plugin
*/
add_action('admin_menu', function(){
    add_menu_page('Vuln', 'Vuln', 'manage_options', 'vuln', 'vuln_page');
});
function vuln_page(){
    echo '<h1>' . ($_GET['msg'] ?? '') . '</h1>';

    if ( ! empty( $_POST['comment'] ) ) {
        // Magic Quotes 等で付いたバックスラッシュを除去
        $raw_comment = wp_unslash( $_POST['comment'] );
        update_option( 'vuln_comment', $raw_comment );
    }

    echo '<form method="post">
            <input name="comment" type="text" />
            <button type="submit">投稿</button>
          </form>';

    // 生の保存データをそのまま出力（脆弱テスト用）
    echo '<div>' . get_option( 'vuln_comment' ) . '</div>';
}
